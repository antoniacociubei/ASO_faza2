#!/bin/bash


service mariadb start

while ! mysqladmin ping --silent; do
    echo "Wait for MariaDB..."
    sleep 2
done

mysql -uroot < /app/db.sql

/app/cnc

